// Selectra Checklist Commerciale - Application JavaScript
class SelectraChecklist {
    constructor() {
        this.startTime = Date.now();
        this.timerInterval = null;
        this.autoSaveInterval = null;
        
        // Configuration des sections
        this.sections = {
            client: {
                name: 'Informations Client',
                total: 8,
                required: 5,
                fields: ['nom', 'prenom', 'adresse', 'email', 'telephone']
            },
            accords: {
                name: 'Accords Explicites',
                total: 6,
                required: 2,
                obligatoires: ['rgpd_donnees', 'acces_reseau'],
                payants: ['axa_assistance', 'compensation_carbone', 'conseiller_perso']
            },
            mentions: {
                name: 'Mentions Légales',
                total: 5,
                required: 2,
                obligatoires: ['frais_mes', 'delai_retractation']
            },
            sms: {
                name: 'Signatures SMS',
                total: 3,
                required: 0
            },
            etapes: {
                name: 'Étapes Commerciales', 
                total: 7,
                required: 0
            }
        };
        
        // État de l'application
        this.state = {
            formData: {},
            checkboxes: {},
            notes: '',
            lastSaved: null
        };
        
        this.init();
    }
    
    init() {
        console.log('🚀 Initialisation Selectra Checklist');
        
        // Charger les données sauvegardées
        this.loadSavedData();
        
        // Démarrer le timer
        this.startCallTimer();
        
        // Configurer les événements
        this.setupEventListeners();
        
        // Auto-sauvegarde toutes les 10 secondes
        this.autoSaveInterval = setInterval(() => {
            this.autoSave();
        }, 10000);
        
        // Validation initiale
        this.updateAllCounters();
        this.updateProgress();
        this.validateMinimumRequirements();
        
        console.log('✅ Checklist initialisée');
    }
    
    // === TIMER D'APPEL ===
    startCallTimer() {
        this.timerInterval = setInterval(() => {
            const elapsed = Date.now() - this.startTime;
            const minutes = Math.floor(elapsed / 60000);
            const seconds = Math.floor((elapsed % 60000) / 1000);
            
            const display = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
            document.getElementById('call-time').textContent = display;
        }, 1000);
    }
    
    // === GESTION DES ÉVÉNEMENTS ===
    setupEventListeners() {
        // Champs de formulaire
        document.addEventListener('input', (e) => {
            if (e.target.matches('input[type="text"], input[type="email"], input[type="tel"], textarea')) {
                this.handleFieldChange(e.target);
            }
        });
        
        // Checkboxes
        document.addEventListener('change', (e) => {
            if (e.target.matches('input[type="checkbox"]')) {
                this.handleCheckboxChange(e.target);
            }
        });
        
        // Boutons des notes
        document.getElementById('clear-notes')?.addEventListener('click', () => {
            this.clearNotes();
        });
        
        document.getElementById('save-notes')?.addEventListener('click', () => {
            this.saveNotes();
        });
        
        // Export et reset
        document.getElementById('export-txt')?.addEventListener('click', () => {
            this.exportToTxt();
        });
        
        document.getElementById('reset-all')?.addEventListener('click', () => {
            this.showResetModal();
        });
        
        // Modal reset
        document.getElementById('cancel-reset')?.addEventListener('click', () => {
            this.hideResetModal();
        });
        
        document.getElementById('confirm-reset')?.addEventListener('click', () => {
            this.resetAll();
        });
        
        // Fermer modal en cliquant à l'extérieur
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('modal')) {
                this.hideResetModal();
            }
        });
    }
    
    // === GESTION DES CHAMPS ===
    handleFieldChange(field) {
        const value = field.value.trim();
        const name = field.name;
        
        // Sauvegarder la valeur
        this.state.formData[name] = value;
        
        // Validation visuelle
        this.validateField(field, value);
        
        // Mettre à jour les compteurs
        this.updateSectionCounter('client');
        this.updateProgress();
        this.validateMinimumRequirements();
    }
    
    validateField(field, value) {
        const isRequired = field.hasAttribute('required');
        const isEmpty = !value;
        
        // Validation spécifique par type
        let isValid = true;
        if (field.type === 'email' && value) {
            isValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
        } else if (field.type === 'tel' && value) {
            isValid = /^[0-9+\s.-]{8,}$/.test(value);
        } else if ((field.name === 'pdl' || field.name === 'pce') && value) {
            isValid = /^\d{14}$/.test(value.replace(/\s/g, ''));
        }
        
        // Appliquer les classes CSS
        field.classList.remove('filled', 'error');
        
        if (isEmpty && isRequired) {
            field.classList.add('error');
        } else if (!isEmpty && isValid) {
            field.classList.add('filled');
        } else if (!isEmpty && !isValid) {
            field.classList.add('error');
        }
    }
    
    // === GESTION DES CHECKBOXES ===
    handleCheckboxChange(checkbox) {
        const name = checkbox.name;
        const checked = checkbox.checked;
        
        // Sauvegarder l'état
        this.state.checkboxes[name] = checked;
        
        // Animation pour les services payants
        if (checkbox.hasAttribute('data-payant') && checked) {
            const item = checkbox.closest('.checkbox-item');
            item.style.transform = 'scale(1.05)';
            setTimeout(() => {
                item.style.transform = 'scale(1)';
            }, 200);
        }
        
        // Mettre à jour les compteurs
        const section = this.getCheckboxSection(name);
        if (section) {
            this.updateSectionCounter(section);
        }
        
        this.updateProgress();
        this.validateMinimumRequirements();
        
        console.log(`✅ Checkbox ${name}: ${checked}`);
    }
    
    getCheckboxSection(name) {
        if (['rgpd_donnees', 'acces_reseau', 'voltalis_rdv', 'axa_assistance', 'compensation_carbone', 'conseiller_perso'].includes(name)) {
            return 'accords';
        } else if (['axa_exclusions', 'axa_rgpd', 'carbone_processus', 'frais_mes', 'delai_retractation'].includes(name)) {
            return 'mentions';
        } else if (['code_axa', 'code_carbone', 'code_mcp'].includes(name)) {
            return 'sms';
        } else if (['client_qualifie', 'besoins_analyses', 'offre_presentee', 'objections_traitees', 'addons_proposes', 'signatures_obtenues', 'recap_final'].includes(name)) {
            return 'etapes';
        }
        return null;
    }
    
    // === COMPTEURS ET PROGRESSION ===
    updateSectionCounter(sectionKey) {
        const section = this.sections[sectionKey];
        if (!section) return;
        
        let count = 0;
        
        if (sectionKey === 'client') {
            // Compter les champs remplis
            Object.keys(this.state.formData).forEach(key => {
                if (this.state.formData[key] && this.state.formData[key].trim()) {
                    count++;
                }
            });
        } else {
            // Compter les checkboxes cochées pour cette section
            Object.keys(this.state.checkboxes).forEach(key => {
                if (this.state.checkboxes[key] && this.getCheckboxSection(key) === sectionKey) {
                    count++;
                }
            });
        }
        
        // Mettre à jour l'affichage
        const counter = document.getElementById(`${sectionKey}-counter`);
        if (counter) {
            counter.textContent = `${count}/${section.total}`;
            
            // Classes CSS pour les couleurs
            counter.classList.remove('complete', 'warning');
            if (count === section.total) {
                counter.classList.add('complete');
            } else if (count >= section.required) {
                counter.classList.add('warning');
            }
        }
        
        return count;
    }
    
    updateAllCounters() {
        Object.keys(this.sections).forEach(key => {
            this.updateSectionCounter(key);
        });
    }
    
    updateProgress() {
        let totalItems = 0;
        let completedItems = 0;
        
        // Calculer le total et les complétés
        Object.keys(this.sections).forEach(key => {
            const section = this.sections[key];
            totalItems += section.total;
            completedItems += this.updateSectionCounter(key);
        });
        
        // Calculer le pourcentage
        const percentage = totalItems > 0 ? Math.round((completedItems / totalItems) * 100) : 0;
        
        // Mettre à jour la barre de progression
        const progressFill = document.getElementById('progress-fill');
        const progressPercentage = document.getElementById('progress-percentage');
        
        if (progressFill) {
            progressFill.style.width = `${percentage}%`;
        }
        
        if (progressPercentage) {
            progressPercentage.textContent = `${percentage}%`;
        }
        
        // Mettre à jour le résumé
        this.updateResumeValues();
        
        return percentage;
    }
    
    updateResumeValues() {
        // Informations client
        const clientCount = this.updateSectionCounter('client');
        document.getElementById('resume-client').textContent = `${clientCount}/8`;
        
        // Accords
        const accordsCount = this.updateSectionCounter('accords');
        document.getElementById('resume-accords').textContent = `${accordsCount}/6`;
        
        // Services payants
        const payantCount = this.getPayantServicesCount();
        const payantElement = document.getElementById('resume-payants');
        payantElement.textContent = `${payantCount}/3 (min 2)`;
        payantElement.classList.toggle('warning', payantCount < 2);
        payantElement.classList.toggle('success', payantCount >= 2);
        
        // Mentions
        const mentionsCount = this.updateSectionCounter('mentions');
        document.getElementById('resume-mentions').textContent = `${mentionsCount}/5`;
        
        // Étapes
        const etapesCount = this.updateSectionCounter('etapes');
        document.getElementById('resume-etapes').textContent = `${etapesCount}/7`;
    }
    
    getPayantServicesCount() {
        const payantServices = ['axa_assistance', 'compensation_carbone', 'conseiller_perso'];
        return payantServices.filter(service => this.state.checkboxes[service]).length;
    }
    
    // === VALIDATION ===
    validateMinimumRequirements() {
        const alerts = document.getElementById('validation-alerts');
        if (!alerts) return;
        
        const issues = [];
        
        // Vérifier les obligatoires
        const obligatoiresManquants = ['rgpd_donnees', 'acces_reseau', 'frais_mes', 'delai_retractation']
            .filter(item => !this.state.checkboxes[item]);
        
        if (obligatoiresManquants.length > 0) {
            issues.push(`Éléments obligatoires manquants: ${obligatoiresManquants.length}`);
        }
        
        // Vérifier les services payants
        const payantCount = this.getPayantServicesCount();
        if (payantCount < 2) {
            issues.push(`Services payants insuffisants: ${payantCount}/2 minimum`);
        }
        
        // Vérifier les champs requis
        const requiredFields = ['nom', 'prenom', 'adresse', 'email', 'telephone'];
        const missingFields = requiredFields.filter(field => !this.state.formData[field] || !this.state.formData[field].trim());
        
        if (missingFields.length > 0) {
            issues.push(`Champs requis manquants: ${missingFields.length}`);
        }
        
        // Afficher les alertes
        if (issues.length > 0) {
            alerts.textContent = '⚠️ ' + issues.join(' • ');
            alerts.className = 'validation-alerts warning';
        } else {
            alerts.textContent = '✅ Tous les éléments critiques sont validés';
            alerts.className = 'validation-alerts success';
        }
    }
    
    // === NOTES ===
    clearNotes() {
        document.getElementById('notes').value = '';
        this.state.notes = '';
        this.autoSave();
    }
    
    saveNotes() {
        const notes = document.getElementById('notes').value;
        this.state.notes = notes;
        this.autoSave();
        
        // Feedback visuel
        const saveBtn = document.getElementById('save-notes');
        const originalText = saveBtn.textContent;
        saveBtn.textContent = '✅ Sauvegardé';
        saveBtn.style.background = 'var(--selectra-success)';
        
        setTimeout(() => {
            saveBtn.textContent = originalText;
            saveBtn.style.background = '';
        }, 2000);
    }
    
    // === SAUVEGARDE ===
    autoSave() {
        try {
            const saveData = {
                ...this.state,
                timestamp: Date.now(),
                callDuration: Date.now() - this.startTime
            };
            
            localStorage.setItem('selectra_checklist', JSON.stringify(saveData));
            this.state.lastSaved = Date.now();
            
            console.log('💾 Auto-sauvegarde effectuée');
        } catch (error) {
            console.warn('⚠️ Erreur sauvegarde:', error);
        }
    }
    
    loadSavedData() {
        try {
            const saved = localStorage.getItem('selectra_checklist');
            if (saved) {
                const data = JSON.parse(saved);
                
                // Restaurer les données
                this.state = { ...this.state, ...data };
                
                // Restaurer les champs
                Object.keys(this.state.formData).forEach(key => {
                    const field = document.querySelector(`[name="${key}"]`);
                    if (field) {
                        field.value = this.state.formData[key];
                        this.validateField(field, this.state.formData[key]);
                    }
                });
                
                // Restaurer les checkboxes
                Object.keys(this.state.checkboxes).forEach(key => {
                    const checkbox = document.querySelector(`[name="${key}"]`);
                    if (checkbox) {
                        checkbox.checked = this.state.checkboxes[key];
                    }
                });
                
                // Restaurer les notes
                if (this.state.notes) {
                    const notesField = document.getElementById('notes');
                    if (notesField) {
                        notesField.value = this.state.notes;
                    }
                }
                
                console.log('📂 Données restaurées');
            }
        } catch (error) {
            console.warn('⚠️ Erreur chargement:', error);
        }
    }
    
    // === EXPORT ===
    exportToTxt() {
        const timestamp = new Date().toLocaleString('fr-FR');
        const callDuration = this.formatDuration(Date.now() - this.startTime);
        
        let content = `SELECTRA - RÉCAPITULATIF COMMERCIAL\n`;
        content += `${'='.repeat(50)}\n`;
        content += `Date: ${timestamp}\n`;
        content += `Durée d'appel: ${callDuration}\n\n`;
        
        // Informations client
        content += `INFORMATIONS CLIENT\n`;
        content += `${'='.repeat(20)}\n`;
        Object.keys(this.state.formData).forEach(key => {
            if (this.state.formData[key]) {
                const label = this.getFieldLabel(key);
                content += `${label}: ${this.state.formData[key]}\n`;
            }
        });
        
        // Accords
        content += `\nACCORDS CONFIRMÉS\n`;
        content += `${'='.repeat(20)}\n`;
        Object.keys(this.state.checkboxes).forEach(key => {
            if (this.state.checkboxes[key]) {
                const label = this.getCheckboxLabel(key);
                content += `✅ ${label}\n`;
            }
        });
        
        // Services payants
        const payantServices = ['axa_assistance', 'compensation_carbone', 'conseiller_perso']
            .filter(service => this.state.checkboxes[service]);
        
        content += `\nSERVICES PAYANTS SOUSCRITS (${payantServices.length}/3)\n`;
        content += `${'='.repeat(30)}\n`;
        payantServices.forEach(service => {
            const label = this.getCheckboxLabel(service);
            content += `💰 ${label}\n`;
        });
        
        // Notes
        if (this.state.notes) {
            content += `\nNOTES D'APPEL\n`;
            content += `${'='.repeat(15)}\n`;
            content += `${this.state.notes}\n`;
        }
        
        // Résumé final
        const progression = this.updateProgress();
        content += `\nRÉSUMÉ FINAL\n`;
        content += `${'='.repeat(15)}\n`;
        content += `Progression globale: ${progression}%\n`;
        content += `Services payants: ${payantServices.length}/3 (minimum 2)\n`;
        content += `Validation: ${payantServices.length >= 2 ? 'CONFORME ✅' : 'NON CONFORME ❌'}\n`;
        
        // Télécharger le fichier
        this.downloadFile(content, `selectra_recap_${new Date().toISOString().split('T')[0]}.txt`);
        
        console.log('📄 Export TXT généré');
    }
    
    getFieldLabel(key) {
        const labels = {
            'nom': 'Nom',
            'prenom': 'Prénom',
            'adresse': 'Adresse',
            'email': 'Email',
            'telephone': 'Téléphone',
            'pdl': 'PDL',
            'pce': 'PCE',
            'iban': 'IBAN'
        };
        return labels[key] || key;
    }
    
    getCheckboxLabel(key) {
        const labels = {
            'rgpd_donnees': 'RGPD données',
            'acces_reseau': 'Accès réseau Enedis/GRDF',
            'voltalis_rdv': 'Voltalis RDV planifié',
            'axa_assistance': 'AXA Assistance 6,99€',
            'compensation_carbone': 'Compensation Carbone',
            'conseiller_perso': 'Mon Conseiller Perso',
            'axa_exclusions': 'AXA 4 exclusions',
            'axa_rgpd': 'AXA RGPD + durée',
            'carbone_processus': 'Carbone processus',
            'frais_mes': 'Frais MES communiqués',
            'delai_retractation': 'Délai rétractation 14j',
            'code_axa': 'Code AXA reçu/validé',
            'code_carbone': 'Code Carbone reçu/validé',
            'code_mcp': 'Code MCP reçu/validé',
            'client_qualifie': 'Client qualifié correctement',
            'besoins_analyses': 'Besoins analysés',
            'offre_presentee': 'Offre présentée clairement',
            'objections_traitees': 'Objections traitées',
            'addons_proposes': 'Add-ons proposés (min 2 payants)',
            'signatures_obtenues': 'Signatures obtenues',
            'recap_final': 'Récap final effectué'
        };
        return labels[key] || key;
    }
    
    downloadFile(content, filename) {
        const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }
    
    formatDuration(ms) {
        const minutes = Math.floor(ms / 60000);
        const seconds = Math.floor((ms % 60000) / 1000);
        return `${minutes}:${seconds.toString().padStart(2, '0')}`;
    }
    
    // === RESET ===
    showResetModal() {
        document.getElementById('reset-modal').classList.remove('hidden');
    }
    
    hideResetModal() {
        document.getElementById('reset-modal').classList.add('hidden');
    }
    
    resetAll() {
        // Confirmer et reset
        this.hideResetModal();
        
        // Effacer le localStorage
        localStorage.removeItem('selectra_checklist');
        
        // Reset de l'état
        this.state = {
            formData: {},
            checkboxes: {},
            notes: '',
            lastSaved: null
        };
        
        // Reset du DOM
        document.querySelectorAll('input[type="text"], input[type="email"], input[type="tel"], textarea').forEach(field => {
            field.value = '';
            field.classList.remove('filled', 'error');
        });
        
        document.querySelectorAll('input[type="checkbox"]').forEach(checkbox => {
            checkbox.checked = false;
        });
        
        // Reset du timer
        this.startTime = Date.now();
        
        // Recalculer
        this.updateAllCounters();
        this.updateProgress();
        this.validateMinimumRequirements();
        
        console.log('🔄 Reset complet effectué');
    }
    
    // === NETTOYAGE ===
    destroy() {
        if (this.timerInterval) {
            clearInterval(this.timerInterval);
        }
        if (this.autoSaveInterval) {
            clearInterval(this.autoSaveInterval);
        }
        console.log('🛑 Checklist détruite');
    }
}

// === INITIALISATION ===
document.addEventListener('DOMContentLoaded', function() {
    console.log('🚀 Démarrage Selectra Checklist Commerciale...');
    
    try {
        // Créer l'instance globale
        window.selectraChecklist = new SelectraChecklist();
        
        // Nettoyage à la fermeture
        window.addEventListener('beforeunload', () => {
            if (window.selectraChecklist) {
                window.selectraChecklist.autoSave();
            }
        });
        
        console.log('✅ Checklist Selectra prête');
        console.log('📊 Auto-sauvegarde: ✓');
        console.log('⏱️ Timer d\'appel: ✓');
        console.log('📄 Export TXT: ✓');
        console.log('🔄 Reset sécurisé: ✓');
        
    } catch (error) {
        console.error('❌ Erreur initialisation:', error);
        alert('Erreur lors du chargement de l\'application. Veuillez actualiser la page.');
    }
});

// === GESTION DES ERREURS ===
window.addEventListener('error', function(e) {
    console.error('❌ Erreur JavaScript:', e.error);
});

window.addEventListener('unhandledrejection', function(e) {
    console.error('❌ Promesse rejetée:', e.reason);
});